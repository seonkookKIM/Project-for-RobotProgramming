import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PointStamped
from nav_msgs.msg import Odometry  # 추가
from nav2_msgs.action import NavigateToPose
from rclpy.action import ActionClient
from geometry_msgs.msg import PoseStamped
import math
import itertools

class path_node(Node):
    def __init__(self):
        super().__init__('goal_subscriber')
        
        # odom 구독자 추가
        self.odom_sub = self.create_subscription(
            Odometry,
            'odom',
            self.odom_callback,
            10
        )
        
        # CamShapeDetector의 /detected_goal 구독
        self.subscription = self.create_subscription(
            PointStamped,
            '/detected_goal',
            self.goal_callback,
            10
        )
        
        # Nav2 액션 클라이언트
        self.client = ActionClient(self, NavigateToPose, 'navigate_to_pose')
        
        # 웨이포인트 저장 변수
        self.waypoints = []
        self.current_position = None  # 현재 위치 (x, y)
        self.path = []
        self.index = 0

    def odom_callback(self, msg):
        # 현재 위치 추출 (맵 기준)
        self.current_position = (
            msg.pose.pose.position.x,
            msg.pose.pose.position.y
        )
        self.get_logger().debug(f'현재 위치: {self.current_position}')

    def goal_callback(self, msg):
        if self.current_position is None:
            self.get_logger().warn("odom 데이터 미수신. 목표점 무시")
            return
            
        new_goal = (msg.point.x, msg.point.y)
        self.waypoints.append(new_goal)
        self.get_logger().info(f'새 목표점 수신: {new_goal}')
        
        if len(self.waypoints) >= 3:
            self.compute_and_navigate()

    def compute_and_navigate(self):
        if self.current_position is None:
            self.get_logger().error("odom 데이터 수신 대기 중...")
            return
            
        self.start_point = self.current_position
        self.path, _ = self.compute_optimal_path(self.start_point, self.waypoints)
        self.index = 1
        self.send_next_goal()

    

def main(args=None):
    rclpy.init(args=args)
    node = path_node()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    
        
    node.destroy_node()    
    rclpy.shutdown()

if __name__ == '__main__':
    main()


